import boto3
import uuid
from datetime import datetime

s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('LogImagenes')

def handler(event, context):
    # 1. Obtener datos del evento de S3
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    
    try:
        # 2. Consultar metadatos técnicos directamente a S3
        response = s3_client.head_object(Bucket=bucket, Key=key)
        
        size_bytes = response['ContentLength']
        size_kb = round(size_bytes / 1024, 2)
        content_type = response['ContentType']
        last_modified = response['LastModified'].strftime('%Y-%m-%d %H:%M:%S')

        print(f"Archivo: {key} | Tamaño: {size_kb} KB | Tipo: {content_type}")

        # 3. Guardar en DynamoDB con todos los metadatos
        table.put_item(Item={
            'ImageID': str(uuid.uuid4()),
            'FileName': key,
            'Bucket': bucket,
            'Size': f"{size_kb} KB",
            'Format': content_type,
            'FileCreationDate': last_modified, # Hora en que se tomó/creó en S3
            'ProcessedAt': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'Status': 'Completado'
        })
        
    except Exception as e:
        print(f"Error procesando {key}: {str(e)}")
        return {"status": "error", "message": str(e)}
    
    return {"status": "ok"}
